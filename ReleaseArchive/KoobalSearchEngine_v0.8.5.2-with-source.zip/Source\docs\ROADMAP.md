# Roadmap (mission-ordered)

Canonical mission: see [`MISSION.md`](MISSION.md).

Ordered so each band deepens **organization + speed + universal access + usefulness** of the parts list:

1. **Current core** — Predictive dropdown on the native editor search bar; parts / filters / mods / authors; history; loading-screen index. *Makes the parts list quickly searchable without replacing stock UI.*
2. **~0.9 — History item delete** — Per-row remove from recent searches. *Keeps history useful and organized instead of only clear-all.* See [`V0_9_HISTORY_ITEM_DELETE.md`](V0_9_HISTORY_ITEM_DELETE.md).
3. **Post-v1 — Categories / subassemblies** — Suggest and jump to category tabs and subassemblies from the same dropdown. *Organizes navigation through the editor’s own taxonomy.* See [`POST_V1_CATEGORIES_SUBASSEMBLIES_PLAN.md`](POST_V1_CATEGORIES_SUBASSEMBLIES_PLAN.md).
4. **Later — Global search halt** — Enter-halt + tight match on every KSP search bar. *Universal access: same fast, deliberate search behavior beyond the editor.* See [`POST_V1_GLOBAL_SEARCH_HALT.md`](POST_V1_GLOBAL_SEARCH_HALT.md).
5. **V2 — Settings + slide-expand** (Track R rebuild gated) — Layout/settings for the parts list experience; preferred Track S slide-expand; optional Track R only with go/no-go. *Makes the list itself more useful and controllable.* See [`V2_PARTS_LIST_AND_SETTINGS.md`](V2_PARTS_LIST_AND_SETTINGS.md).

Longer / partially stale feature notes remain in [`../ROADMAP.md`](../ROADMAP.md); this file is the mission-aligned order of work.
