﻿# Rollback artifacts moved

v0.7.0 rollback files (DLL, version, README) now live under:

  Source/PartSearchSuggest/rollback/v0.7.0/

KSP scans all *.dll under GameData/ — rollback DLLs must NOT stay here or the plugin loads twice.

See Source/PartSearchSuggest/ROLLBACK.md for restore instructions.

Current mod folder: GameData/KoobalSearchEngine/
