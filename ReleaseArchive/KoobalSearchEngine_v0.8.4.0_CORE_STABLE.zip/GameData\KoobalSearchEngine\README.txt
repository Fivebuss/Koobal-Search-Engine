# Koobal Search Engine

Predictive search for the VAB — proof-of-concept plugin that attaches a dropdown to the **native** VAB/SPH search bar.

*A Kerbalized play on Google search — "Koobal" blends Kerbal + Google (same spirit as the prior "Koogle" name).*

*(Formerly Part Search Suggest / PartSearchSuggest; formerly Koogle Search Engine.)*

## Branding (v0.8.3.2+)

The empty-search dropdown footer shows a **programmatic TextMeshPro wordmark** — a Google Catull-style parody with classic multicolor letters on a **fully transparent** background (no PNG white-box issues).

| Letter | Color |
|--------|-------|
| K | blue `#4285F4` |
| o | red `#EA4335` |
| o | yellow `#FBBC05` |
| b | green `#34A853` |
| a | red `#EA4335` |
| l | blue `#4285F4` |

**Switch dropdown variant:** edit `PluginData/BrandingSettings.cfg`:

```
dropdownBranding = Wordmark
```

or `dropdownBranding = FullTagline` (adds **SEARCH ENGINE** subtitle + *for Kerbal Space Program* micro text), then **restart the VAB/SPH** (config loads once per game session).

Optional marketing PNGs may live under `Textures/` for mod-page use; the in-game dropdown uses TMP only.

## v0.8.4.0 changes (CORE-ONLY RE-BASELINE — de-risk, stock UI now 100% native)

**Why:** the v0.8.1–v0.8.3 line dove deep into stock editor internals (category tabs,
filter buttons, subassembly tab, delete flow) to add subassembly and custom-category
search. That repeatedly broke stock behavior (empty parts lists, dead category buttons,
delete lockups, CTDs). v0.8.4.0 **strips the mod back to the stable v0.7.x core** that was
verified working, keeps thumbnails + branding, and **removes every invasive integration**.

### HARD RULE now enforced
After this release the mod does **NOT** patch, mutate, or drive stock category tabs, filter
buttons, the subassembly tab, or the delete flow. Stock parts list, filter buttons
(Structural/RCS/Control/…), category tabs, subassembly tab, and subassembly delete all
behave **100% natively**. The only ways Koobal touches stock are:
1. **Passive reads** of part metadata / CKAN registry / cfg / live `PartCategorizer`
   buttons — to build suggestions and resolve display icons (read-only).
2. **The stable v0.7.x suggestion-apply path** — set the search field text without notify,
   then apply a Koobal `EditorPartListFilter` via `SearchFilterResult` +
   `editorPartList.Refresh(PartSearch)` (categorizer / author / mod / precise-part).

### Removed (features AND their code/patches)
- **Subassembly search** entirely: `SubassemblyMatcher`, `SubassemblyEntry`,
  `SubassemblySuggestionIndex`, `StockSubassemblyHelper`, `SubassemblyLifecycleHooks`, the
  `AllSubassemblies` suggestion, and `SuggestionKind.Subassembly` / `AllSubassemblies`.
- **Custom-category search** entirely (part + subassembly): `CustomCategoryMatcher`,
  `CustomCategoryEntry`, `CustomCategorySuggestionIndex`, `StockCustomCategoryHelper`,
  `CustomCategoryLifecycleHooks`, `CustomCategoryCfgReader`, and the `CustomPartCategory` /
  `CustomSubassemblyCategory` suggestion kinds.
- **`StockTabNavigator`** and all "navigate to tab" apply logic.
- **`PartCategorizerUiHelper`** (stock tab activation via `OnTrueSUB`/`OnTrueCATEGORY`/
  `SetState`/button `OnTrue`, `EnsureCategoryChainDisplayType`,
  `RestoreAllCapturedDisplayTypes`, `ActivateSimplePartsMode` displayType writes — all gone).
- **Every Harmony patch touching stock parts-list/filter/tab/subassembly/delete internals:**
  `OnTrueSUB`/`OnTrueCATEGORY`/`OnFalse*`, `EditorPartList.RefreshSubassemblies`,
  `EditorSubassemblyItem.MouseInput_Delete`/`MouseInput_Spawn`/`OnDismiss`,
  `DeleteSubassembly`/`SaveSubassembly`, `LoadCustomPartCategories`/
  `LoadCustomSubassemblyCategories`, `AcceptNewSubcategory`, `AddPart`/`AddSubassembly`,
  `DeleteSubcategory`/`DeleteCategory`, and all displayType snapshot/restore logic.
- **StockSearchGuard typing-suppression / refresh-blocking:** removed the
  `SearchField_OnValueChange` and `SearchStart` typing-pipeline blocks, the
  `PartCategorizer.SearchStop` refresh-suppression patch, and the `EditorPartList.Refresh`
  block. Stock typing/refresh now runs natively.

### Kept (stable core)
- Predictive search dropdown on the stock search bar (open/close, scroll, click-to-apply, X
  close, clear-history trashcan).
- Metadata-driven suggestions: part names, stock categorizer filters/categories (functions,
  manufacturers, diameter, tags, modules, resources, tech), mod author, mod name, mod suite —
  from part metadata + CKAN registry.
- Search history (persistent, clear button); 0-part suppression; single-letter/symbol
  suppression; dedup of suggestions with identical part sets.
- Suggestion-click apply via the stable v0.7.x path (search field + `Refresh(PartSearch)` /
  categorizer `SearchFilterResult`).
- Branding: Google-Catull-parody wordmark footer on empty query; `BrandingSettings.cfg`
  Wordmark/FullTagline toggle; Textures PNGs; history-scrolls-above-branding.
- Read-only category display icons on `FilterFunction` / `FilterCategory` rows, resolved from
  live `PartCategorizer` buttons (icon eligibility: only real category rows; other filter
  kinds are text-only).

### Minimal StockSearchGuard retained (v0.6.7-era race guard only)
While Koobal is applying a suggestion filter (`EnterSuppress`) or a Koobal custom filter is
active, block stock's async `SearchRoutine` / `SearchFilterResult` from overwriting the
applied result. Nothing else is patched.

### v0.8.4.0 test checklist (ModTest VAB)
1. Stock category buttons (Structural/RCS/Control/…) filter **100% natively**.
2. Stock subassembly tab + custom subassembly categories + delete all behave **natively**
   (mod no longer touches them).
3. Dropdown suggests part names, categories/filters, manufacturers, tags, authors, mod
   names/suites.
4. Suggestion click applies the correct filter/search and populates the parts list.
5. Search history + clear works.
6. Branding footer on empty query; Wordmark/FullTagline toggle.
7. Category suggestions show display icons; non-category suggestions text-only.
8. 0-part suppression, single-letter suppression, dedup still work.
9. `KSP.log`: no exceptions; no Harmony patches on stock category/subassembly/refresh/delete
   methods (only `KoobalSearchEngine.StockSearchGuard` + `PartsPanelTransitionGuard`).

## v0.8.3.17 changes (CRITICAL — stock category buttons fixed)

**Regression fixed:** in v0.8.3.16 the stock part-category buttons (Structural, RCS,
Control, Coupling, Payload, …) stopped responding to clicks — clicking a category no
longer filtered the parts list.

### Root cause

v0.8.3.16 mutated `PartCategorizer.Category.displayType` **on the stock click path**:

- An `OnTrueCATEGORY` prefix (`StockCategoryTabDisplayTypePatch` /
  `EnsureCategoryChainDisplayType`) forced a computed `displayType` onto every clicked
  top-level category **and its whole parent chain** on every stock category click.
- The `OnTrueSUB` prefix did a snapshot/restore (`RestoreOriginalDisplayTypeChain`) that
  also wrote `displayType` while stock click handlers were running.

Stock `OnTrueSUB` / `OnFalseSUB` / `OnFalseFilterOrCategory` / `RemoveSubcategoryButtons`
all branch on `displayType`, and the parts list is blanked via `filterGenericNothing`
when that state machine is inconsistent. Writing `displayType` from inside the stock
click path desynced the state machine, so the stock category buttons silently stopped
filtering (no exception — the list just goes empty / unresponsive).

### Fix (v0.8.3.17)

- **Koobal NEVER writes `displayType` from a stock click handler.** The
  `OnTrueCATEGORY` forced-`displayType` patch is **removed**. The remaining
  `OnTrueCATEGORY` / `OnTrueSUB` prefixes are pure, fail-open **no-ops for stock
  categories**: they only clear Koobal's own (now inert) transient filter, are wrapped in
  try/catch so any exception is swallowed and stock always runs, and they are `void`
  prefixes so they can never skip the stock method.
- **`displayType` is only touched transiently inside Koobal's own programmatic apply**
  (`StockTabNavigator.BeginTabApply` scope). Every value written by
  `EnsureCategoryChainDisplayType` is snapshotted and reverted by
  `RestoreAllCapturedDisplayTypes()` the instant the apply scope disposes — before control
  returns to the game — so stock click handlers always observe pristine stock values.
- **`ActivateSimplePartsMode` no longer writes `displayType`** (search display is driven
  by `EditorPartList.Refresh(PartSearch)`, which never reads `Category.displayType`).
- The custom subassembly tab-scoping feature is preserved via the fail-open `OnTrueSUB`
  prefix (recompiles the stock `exclusionFilterSubassembly` only for real subassembly
  categories; stock part subcategories fall straight through untouched).

**Preserved from v0.8.3.16:** the delete-popup guard (delete dialog no longer locks the
UI), custom subassembly tab scoping, navigate-only suggestion apply, branding, icons,
dropdown, and icon eligibility.

### v0.8.3.17 test steps (ModTest VAB, pristine entry)

1. Click **Structural**, **RCS**, **Control** stock categories → parts filter normally (PRIMARY).
2. Delete a subassembly → dialog works; **Cancel** and **Delete** both work; no UI lockup.
3. Custom subassembly category tab → scoped list; empty category → empty; **All Subassemblies** → all.
4. Suggestion apply still navigates to the owning tab (navigate-only).
5. `KSP.log`: no `NullReferenceException` and no state desync on category clicks;
   `OnTrueSUB prefix patched for subassembly tab navigation.` present.

> Emergency stock-safe fallback: a conservative build with the `OnTrueSUB` /
> `OnTrueCATEGORY` prefixes **disabled** (Harmony never touches those stock methods) is
> exported alongside this release as
> `KoobalSearchEngine_v0.8.3.17-fallback_STABLE_FALLBACK.zip`. Custom subassembly tab
> scoping is degraded in that build, but stock category clicks are guaranteed native.

## v0.8.3.16 changes (CRITICAL — delete dialog + subassembly tab scoping)

Two game-breaking regressions reported on v0.8.3.15 are fixed. Both root causes were
confirmed against decompiled stock IL (`EditorPartList.State`, `EditorSubassemblyItem`,
`PartCategorizer.Category.OnTrueSUB`).

### Correct enum values (source of both bugs)

Prior release notes (v0.8.3.13–15) mislabeled `EditorPartList.State`. The stock enum is:

```
PartsList = 0, SubassemblyList = 1, CustomPartList = 2, PartSearch = 3, Nothing = 4, VariantsList = 5
```

Stock `Category.OnTrueSUB(cat)` adds `cat.exclusionFilterSubassembly` to `ExcludeFiltersSubassembly`
**only when `cat.displayType == SubassemblyList (1)`** — NOT `PartSearch`. Enum value `1` is
`SubassemblyList`. The earlier "PartSearch (1)" wording was wrong and led v0.8.3.14 to remove the
correct `SubassemblyList` behavior, which is what broke tab scoping.

### Bug 1 — Delete popup broken (GAME BREAKING)

**Root cause:** while the stock confirm dialog was open, a background subassembly-list rebuild
(`Refresh(SubassemblyList)` → `RefreshSubassemblies` → `RefreshSubassemblyList` → `ClearAllItems`)
destroyed the live `EditorSubassemblyItem` backing the dialog. Koobal's typing-guard `Refresh`
patch explicitly *allows* `SubassemblyList` refreshes through, so this rebuild slipped in silently.
When the user then clicked Cancel or Delete, `EditorSubassemblyItem.OnDismiss()` called
`StartCoroutine(OnDismissCoroutine())` on the destroyed object → `NullReferenceException`. The
exception aborted the dialog's dismiss, so the popup could not be closed and the UI stayed locked;
the craft file (deleted by `File.Delete` before `OnDismiss`) appeared to vanish.

**Fix:**
- New `_subassemblyDeleteDialogOpen` guard, set in a `MouseInput_Delete` **postfix** (dialog opened)
  and cleared in an `OnDismiss` **prefix** (Cancel or confirmed Delete).
- New prefix on `EditorPartList.RefreshSubassemblies` that **skips the rebuild while the guard is
  set**, so the item survives the whole dialog. Stock's own `OnDismissCoroutine` refresh (two frames
  after `OnDismiss` clears the guard) rebuilds the list normally after a confirmed delete.
- Index update stays in the `DeleteSubassembly` **postfix** (runs after stock confirms). Nothing
  deletes or refreshes in a prefix; no Koobal `Refresh` is called while the dialog is open.

### Bug 2 — Custom subassembly tabs showed ALL crafts

**Root cause:** custom subassembly categories are constructed by stock with
`displayType == SubassemblyList (1)`, and stock `OnTrueSUB` needs that value to scope the list.
Koobal's `OnTrueSUB` prefix overwrote `displayType` with `ResolveCategoryDisplayState(cat)`, which
returned `PartsList (0)`. Stock then took the *parts* branch (added `exclusionFilter` to
`CategorizerFilters` instead of the subassembly filter), so the subassembly list was never scoped
and every craft showed on every custom subassembly tab, including empty ones.

**Fix:**
- Koobal no longer forces a computed `displayType` in the `OnTrueSUB` prefix. Instead it records the
  stock-original `displayType` the first time it touches a category (in
  `EnsureCategoryChainDisplayType`) and **restores that exact value** before the stock handler runs
  (`RestoreOriginalDisplayTypeChain`). Categories Koobal never touched keep their already-correct
  value. Part subcategories (displayType `CustomPartList`) are unaffected — they still take the
  stock parts branch, exactly as before.
- The registry is cleared on editor re-entry (categories are rebuilt each time).

### v0.8.3.16 test steps (ModTest VAB, pristine entry)

1. Trash a subassembly → confirm dialog appears; **Cancel** closes it, craft still present.
2. Trash → **Delete** → exactly one craft removed, list updates after confirm, no UI lockup, no NRE.
3. Click a custom subassembly category tab → only that category's crafts show.
4. Empty custom subassembly category → empty list.
5. **All Subassemblies** → all crafts.
6. Search suggestion apply still navigates to the owning tab (navigate-only, no single-craft filter).
7. `KSP.log`: `Blocked EditorPartList.RefreshSubassemblies while subassembly delete dialog is open.`
   during a delete, and no `NullReferenceException` from `OnDismiss`.

**Preserved from prior versions:** navigate-only suggestion apply (no transient single-craft
filter), custom part categories, branding wordmark, dropdown, icons, and icon eligibility.

## v0.8.3.15 changes (subassembly navigate-only — list stability fix)

**Root cause (ModTest after v0.8.3.14):**

1. **Category-scoped transient filter in `ExcludeFiltersSubassembly`** — when active, stock `FilterList` removes every craft whose predicate returns false. The single-craft filter hid all non-target crafts and used `SelectedCategory` to gate visibility, so tab switches and partial clears caused crafts to pop in/out unpredictably.
2. **Filter clear without list refresh** — tab-change and delete hooks cleared the Koobal filter with `refreshList: false`, leaving stale `ShipTemplate` entries in the stock list until the user clicked a craft (`MouseInput_Spawn` refreshed with `refreshList: true`).
3. **Delete ghost entries** — deleted crafts could linger in the UI until interaction triggered a refresh; index removal was correct but the stock subassembly list was not rebuilt after delete.

**Fix (v0.8.3.15):**

- **Navigate-only subassembly apply** — suggestion apply switches to the owning subassembly category tab (or All Subassemblies) and shows the **full stock category list**. No Koobal `ExcludeFiltersSubassembly` filter. Tradeoff: user may need to scan a short category list instead of seeing a single filtered craft; list stability is prioritized over single-craft isolation.
- **Delete refresh** — `DeleteSubassembly` postfix removes the craft from `SubassemblySuggestionIndex`, rescans custom subassembly categories, and calls `Refresh(SubassemblyList)` immediately.
- **Removed** transient filter machinery (auto-clear coroutine, category-scoped predicate, filter add/remove, `MouseInput_Spawn` filter-clear hook).

### v0.8.3.15 test steps (ModTest VAB)

1. Delete **Unnamed2** → immediately gone from all tabs; **Unnamed** still visible where expected.
2. No ghost crafts lingering until click.
3. Place subassembly → remains in category list.
4. Tab switching stable — no pop in/out without suggestions.
5. Search suggestion apply still navigates to correct category (full list, not filtered).
6. `KSP.log`: `ApplySubassembly: navigated ... (navigate-only, no filter).` and `DeleteSubassembly: index updated and subassembly list refreshed.`

## v0.8.3.14 changes (stock subassembly tab scoping + delete path fix)

**Root cause (ModTest KSP.log after v0.8.3.13):**

1. **`OnTrueSUB` prefix overwrote `Category.displayType` to `SubassemblyList`** — stock `OnTrueSUB` only adds `exclusionFilterSubassembly` when `displayType == PartSearch` (enum value 1). Forcing `SubassemblyList` skipped stock category filters, so every custom subassembly tab showed all crafts.
2. **Postfix `Refresh(SubassemblyList)` raced stock tab handling** — redundant refresh after `OnTrueSUB` could run before stock compiled/applied the category filter, and clearing Koobal filters called `StopActiveSearchForStockUi` which cleared `refreshRequested`.
3. **Delete index removed wrong/missing craft** — `DeleteSubassembly` postfix read `__instance.subassembly` after stock delete had already mutated the UI item; index could remove the wrong path or nothing while the UI looked empty everywhere.

**Fix (v0.8.3.14):**

- **`OnTrueSUB` prefix:** only clear Koobal transient filter when active; **do not** set `displayType` or refresh the list.
- **Removed `OnTrueSUB` / `OnTrueCATEGORY` postfix refresh** — stock handlers own tab refresh.
- **Tab filter clear:** `ClearTransientSubassemblyFilter(..., stopStockSearch: false)` during manual tab navigation so stock refresh state is preserved.
- **`DeleteSubassembly` prefix:** capture craft path before stock delete; postfix removes exactly that path from `SubassemblySuggestionIndex`.

### v0.8.3.14 test steps (ModTest VAB)

1. Pristine VAB entry → manual custom subassembly category tab → **only** that category's crafts.
2. Manual **All Subassemblies** tab → all crafts.
3. Delete **unna 2** → only that craft gone; **Unnamed1** remains on disk and in other tabs.
4. Search suggestion apply for a single craft still works; manual tab change clears Koobal filter.
5. `KSP.log`: `OnTrueSUB prefix patched for subassembly tab navigation.` — no mass delete paths logged.

## v0.8.3.13 changes (subassembly filter lifecycle + OnTrueSUB patch fix)

**Root cause (ModTest KSP.log after v0.8.3.12):**

1. **`OnTrueSUB` Harmony patch still failed to apply** — log showed `Harmony patch skipped for StockSubcategoryTabPatch`. Attribute-based patch on `Category::OnTrueSUB(Category)` could not attach, so manual custom subassembly tab clicks never cleared the Koobal `ExcludeFiltersSubassembly` filter and never corrected `Category.displayType`.
2. **Global transient filter leaked across tabs** — the single-craft suggestion filter stayed in `ExcludeFiltersSubassembly` until search-field focus or timeout, so the suggested craft appeared in every subassembly tab.
3. **All Subassemblies manual tab** — stale Koobal filter and/or wrong `displayType` on subcategory navigation left stock category filters misapplied.

**Fix (v0.8.3.13):**

- **`SubassemblyLifecycleHooks`:** apply `OnTrueSUB` prefix/postfix via **manual `AccessTools` patch** (not attribute) — clears Koobal filter before stock handler, sets `displayType` on subcategory chain, refreshes subassembly list after stock tab handler completes.
- **`OnTrueCATEGORY`:** postfix refresh when Koobal filter cleared on subassembly root/custom category tabs.
- **`StockSubassemblyHelper`:** category-scoped transient filter — single-craft predicate only keeps the craft when `SelectedCategory` is the owning category (safety net if filter clear is delayed).

### v0.8.3.13 test steps (ModTest VAB)

1. Manual **All Subassemblies** tab → all crafts visible.
2. Manual custom subassembly category tab → only that category's crafts.
3. Search `unna` → **unna 2** suggestion → filtered to that craft in **Test category**.
4. Then click a different subassembly tab manually → stock scoped list; **unna 2** not visible in wrong tabs.
5. Search `unnamed` → **Unnamed1** suggestion → same; no leak after manual navigation.
6. Search `all sub` → **All Subassemblies** suggestion still works.
7. `KSP.log`: `OnTrueSUB prefix/postfix patched for subassembly tab navigation.` — no `StockSubcategoryTabPatch` patch skipped.

## v0.8.3.12 changes (subassembly category scoping fix + All Subassemblies suggestion)

**Root cause (ModTest KSP.log after v0.8.3.11):**

`StockSubcategoryTabDisplayTypePatch` in `CustomCategoryLifecycleHooks` **still failed to apply** — Harmony reported `Patching exception in method Category::OnTrueSUB`. A duplicate `OnTrueSUB` prefix in a second patch class could not attach, so `Category.displayType` was never set to `SubassemblyList` on manual custom subassembly tab clicks. Stock `OnTrueSUB` then added the category's **parts** `exclusionFilter` to `CategorizerFilters` instead of `exclusionFilterSubassembly` to `ExcludeFiltersSubassembly` — every custom subassembly tab showed **all** crafts.

**Fix (v0.8.3.12):**

- **`SubassemblyLifecycleHooks`:** merged displayType correction into the working `OnTrueSUB` prefix (same class that clears Koobal transient filters) — sets `Category.displayType` on subcategory + parent chain before stock handler runs.
- **`CustomCategoryLifecycleHooks`:** removed duplicate failed `OnTrueSUB` patch; `OnTrueCATEGORY` displayType prefix retained for part categories and `subassembliesAll` root tab.
- **All Subassemblies suggestion:** new `SuggestionKind.AllSubassemblies` indexed from stock `subassembliesAll` tab — matches `all sub`, `subassemblies`, `all subs`; apply navigates to All Subassemblies with no Koobal filter.

### v0.8.3.12 test steps (ModTest VAB)

1. Custom subassembly category **Test category** → only its crafts (not all).
2. New empty subassembly category → empty list.
3. Search `all sub` → **All Subassemblies** suggestion → shows all crafts.
4. Search `unna` → **unna 2** craft suggestion → single craft filter still works.
5. Custom **part** categories still work; no duplicate subassembly tabs.
6. `KSP.log`: no `Harmony patch skipped for StockSubcategoryTabDisplayTypePatch`.

## v0.8.3.11 changes (subassembly filter inversion + Harmony patch fix)

**Root causes (ModTest KSP.log after v0.8.3.10):**

1. **Subassembly suggestion filter inverted:** `ExcludeFiltersSubassembly` uses `EditorPartListFilter.FilterList`, which **removes** items when the predicate returns **false** (true = keep). v0.8.3.10 used `!TemplateMatchesCraftPath`, so clicking **unna 2** kept **Unnamed1** and vice versa — exact swap with two crafts in the same category.
2. **Custom category lifecycle hooks never applied:** Harmony prefix on `Category.OnTrueSUB` used `(object __instance, object sub)` instead of `(PartCategorizer.Category, PartCategorizer.Category)`. Patch failure aborted the entire `CustomCategoryLifecycleHooks` batch — `Category.displayType` was never corrected on manual tab clicks, so custom **part** categories still opened with subassembly UI (duplicate subassembly tabs, extra **add custom subcategory** button).

**Fix (v0.8.3.11):**

- **`StockSubassemblyHelper`:** transient filter returns `TemplateMatchesCraftPath` (no negation) — show only the indexed craft by full path / filename / case-insensitive stem.
- **`CustomCategoryLifecycleHooks`:** correct Harmony prefix parameter types; `OnTrueCATEGORY` uses `ResolveCategoryDisplayState` (subassembly root tab + subassembly parent chain → `SubassemblyList`, else `PartsList`).
- **`HarmonyPatchHelper`:** patch nested types individually — one bad signature no longer disables all lifecycle hooks.

### v0.8.3.11 test steps (ModTest VAB)

1. Search `unna` → click **unna 2** → only **unna 2** visible in **Test category**.
2. Search `unnamed` → click **Unnamed1** → only **Unnamed1** visible.
3. Search `unknown` → custom **part** category → Advanced parts view, **no** duplicate subassembly UI, **no** extra add-subcategory button.
4. Custom **subassembly** category tabs still scoped (v0.8.3.9 behaviour).
5. `KSP.log`: `Custom category lifecycle hooks applied.` — not patch failed on `OnTrueSUB`.

## v0.8.3.10 changes (Category.displayType fix — part/subassembly tab regression)

**Root causes (after v0.8.3.9):**

1. **Wrong displayType target:** v0.8.3.7 set `PartCategorizer.displayType`, but stock `Category.OnTrueSUB` reads **`Category.displayType`** on the subcategory being activated. After a subassembly apply, part-category tab handlers saw `displayType != SubassemblyList` inconsistently — custom **part** categories opened with subassembly exclusion filters/UI mixed in (duplicate subassembly panels, **Unna 2** / **Unnamed1** visible in part tabs).
2. **Subassembly filter before category compile:** `ApplySubassembly` added the Koobal `ExcludeFiltersSubassembly` entry **before** stock `OnTrueSUB` compiled/applied the owning category's `exclusionFilterSubassembly`. With wrong `displayType`, stock added a **parts** exclusion filter instead of subassembly — **Unnamed1** filtered incorrectly (wrong craft visible / hidden until another craft selected).

**Fix (v0.8.3.10):**

- **`PartCategorizerUiHelper`:** set `Category.displayType` on the target category **and parent chain** before any `OnTrueSUB` / `OnTrueCATEGORY` handlers (`EnsureCategoryChainDisplayType`).
- **`ApplySubassembly`:** activate owning category tab first, **then** add Koobal transient filter, then `Refresh(SubassemblyList)`.
- **`CustomCategoryLifecycleHooks`:** Harmony prefix on stock `OnTrueSUB` / `OnTrueCATEGORY` ensures correct `Category.displayType` on manual tab clicks (skipped during Koobal `EnterSuppress` apply — our apply path sets it explicitly).
- v0.8.3.9 narrow filter-clear behaviour retained (no regress on custom subassembly category scoping).

### v0.8.3.10 test steps (ModTest VAB)

1. Search `unknown` → custom **part** category → Advanced parts view only, **no** subassembly duplicate panel.
2. Search `un` → **Unnamed1** subassembly suggestion → **Test category** tab, **Unnamed1** visible (not swapped with **unna 2**).
3. Custom **subassembly** category tabs still scoped (not all crafts).
4. Create new empty subassembly category → still empty.
5. Alternate part/subassembly suggestion clicks → no UI corruption; manual stock tab clicks after apply still correct.

## v0.8.3.9 changes (custom subassembly category scoping fix)

**Root cause (after v0.8.3.8):**

v0.8.3.8 cleared the transient subassembly filter on *every* stock category tab click and `Refresh(SubassemblyList)` — even when no Koobal filter was active. The no-op path still called `StopActiveSearchForStockUi`, resetting stock search/refresh flags and racing stock `Category.OnTrueSUB`, which adds each category's `exclusionFilterSubassembly` to `ExcludeFiltersSubassembly`. Result: custom subassembly category tabs behaved like **All Subassemblies** (every craft visible; new empty categories pre-populated).

**Fix (v0.8.3.9):**

- **`ClearTransientSubassemblyFilter`:** no-op when Koobal filter (`KoobalSearchEngine_Subassembly`) is not active — never touches stock `ExcludeFiltersSubassembly` entries or calls `StopActiveSearchForStockUi` during normal tab navigation.
- **`SubassemblyLifecycleHooks`:** stock tab hooks (`OnTrueSUB` / `OnTrueCATEGORY`) and editor tab-change hook only clear when `HasActiveSubassemblyFilter`; removed `Refresh(SubassemblyList)` prefix hook (stock category compile/add must not be raced).

### v0.8.3.9 test steps (ModTest VAB)

1. Stock **Subassemblies** → custom **Test category** → only crafts in that category (not all).
2. Create new custom subassembly category → empty (not all crafts).
3. Move subassembly into category → appears only there.
4. Search subassembly suggestion → apply still navigates + filters single craft; manual tab change clears Koobal filter.
5. Custom **part** categories still work.
6. `KSP.log`: no `ClearTransientSubassemblyFilter` spam on manual tab clicks unless a prior suggestion left the Koobal filter active.

## v0.8.3.8 changes (stock subassemblies tab fix)

**Root causes (ModTest KSP.log after v0.8.3.7):**

1. **Typing guard blocked stock tab refresh:** `StockSearchGuard` blocked `EditorPartList.Refresh` for *all* states while the Koobal search field was focused. Manual Subassemblies tab clicks call `Refresh(SubassemblyList)` — blocked, so the tab never populated.
2. **Subassembly lifecycle hooks never applied:** Harmony patch targeted `EditorSubassemblyItem.MouseInput_click`, but stock KSP 1.12.5 uses `MouseInput_Spawn`. Patch failure (`method null`) disabled *all* subassembly lifecycle hooks — filter clear on tab change, craft click, and delete never ran.
3. **Transient filter stuck after suggestion:** With hooks disabled, `ExcludeFiltersSubassembly` from a prior subassembly suggestion could remain when clicking stock tabs manually.

**Fix (v0.8.3.8):**

- **`StockSearchGuard`:** typing guard still blocks `Refresh(PartSearch)` only; `Refresh(SubassemblyList)` and `Refresh(PartsList)` always allowed for stock tab navigation.
- **`SubassemblyLifecycleHooks`:** patch `MouseInput_Spawn` (not `MouseInput_click`); add stock tab hooks on `Category.OnTrueSUB` / `OnTrueCATEGORY`; clear transient subassembly filter on manual subassembly-list refresh (skipped during Koobal `EnterSuppress` apply).
- **`EditorSearchHook`:** clear transient subassembly + custom category filters on VAB/SPH editor init.

### v0.8.3.8 test steps (ModTest VAB)

1. VAB entry → click stock **Subassemblies** tab → crafts/categories visible (no empty list).
2. Click custom subassembly category tab in stock UI → works.
3. Search `un` → subassembly suggestion → navigate + filter → place craft → tab still works.
4. Switch away from Subassemblies and back → still works.
5. `KSP.log`: `Subassembly lifecycle hooks applied.` — **not** patch failed; no `Blocked EditorPartList.Refresh(SubassemblyList)` on manual tab click; `ClearTransientSubassemblyFilter: stock-category-tab` / `subassembly-list-refresh` after manual navigation.

## v0.8.3.7 changes (custom part category display mode fix)

**Root cause (after v0.8.3.6):**

1. **Part categories opened in subassembly UI:** `ActivateCategorySelection` set `displayType` to `PartsList` *after* stock tab handlers ran. If the editor was still on the Subassemblies tab from a prior apply, stock handlers rebuilt subassembly UI — custom part categories looked like duplicate subassembly pages (e.g. **Unna 2** / **Unnamed1** visible while clicking a part category).
2. **Duplicate subassembly tab activation:** `ApplySubassemblyCategory` and `ApplySubassembly` called `ActivateSubassemblyRootTab` (`subassembliesAll`) and then `ActivateCategorySelection`, which walks the parent chain (`subassembliesAll` → `subassemblies` → category) — activating the subassembly root twice.

**Fix (v0.8.3.7):**

- **`ActivateCategorySelection`:** set `displayType` (`PartsList` / `SubassemblyList` / `PartSearch`) **before** parent/subcategory tab activation so stock handlers run in the correct list mode.
- **`ApplyPartCategory`:** single `BeginTabApply` scope — Advanced mode + category tabs + `Refresh(PartsList)`; never calls subassembly root activation.
- **`ApplySubassemblyCategory`:** parent-chain activation only (no redundant `ActivateSubassemblyRootTab`).
- **`ApplySubassembly`:** `ActivateSubassemblyRootTab` only when no owning custom category; otherwise parent-chain activation only.

### v0.8.3.7 test steps (ModTest VAB)

1. Search `un` → click subassembly **unna 2** → Subassemblies → **Test category** → one craft filtered.
2. Search `unknown` → click custom **part** category (e.g. **Unknown › Unknown**) → Advanced parts view, correct category — **not** subassembly page, no **Unna 2** in list.
3. Click custom **subassembly** category **Test category** → single subassembly tab view, correct category (no duplicate subassembly panels).
4. Alternate part-category and subassembly-category clicks — no duplicate subassembly pages.
5. `KSP.log`: expect `ApplyPartCategory: navigated` with parts list; no double subassembly root activation.

## v0.8.3.6 changes (custom category + subassembly apply fix)

**Root causes (ModTest KSP.log after v0.8.3.5):**

1. **Custom category NRE:** `ApplyPartCategory` called `EditorPartList.Refresh(PartSearch)` after clearing search state. Stock `RefreshSearchList()` null-ref'd — dropdown never hid because the exception aborted `ApplySuggestion` before cleanup (`_applyingSuggestion` stuck true).
2. **Subassembly crafts vanishing:** Transient `ExcludeFiltersSubassembly` filter stayed active when clicking to place via stock UI. Filter clears + list refresh were blocked by typing guard once `EnterSuppress` exited.
3. **Subassembly category not found:** `TryFindSubassemblyCategoryForCraft` compared full craft paths against cfg `shipTemplates` entries that store bare names (`Unnamed1`), so owning category tab never activated.

**Fix (v0.8.3.6):**

- **`ApplySuggestion`:** try/catch/finally — always hide dropdown and reset `_applyingSuggestion` even when apply throws.
- **`ApplyPartCategory`:** Advanced custom categories refresh `PartsList` (not `PartSearch`); `EnsurePartsListDisplay` before refresh.
- **`RefreshPartListSafely`:** wraps refresh with PartSearch→PartsList fallback on failure.
- **`ClearTransientSubassemblyFilter` / `ClearTransientCustomCategoryFilter`:** lift typing guard during refresh so stock list updates after filter clear.
- **`MouseInput_click` hook:** clear transient subassembly filter when user clicks to use a craft.
- **`CraftPathsReferToSameSubassembly`:** match full path, filename, or cfg stem for category ownership lookup.

### v0.8.3.6 test steps (ModTest VAB)

1. Search `un` → click subassembly → Subassemblies tab → **Test category** tab (if cfg owns craft) → one craft filtered → click to place → craft **still in list**.
2. Search `test` → click custom part category → dropdown **closes** → Advanced + parent + subcategory.
3. Click custom subassembly category → dropdown closes → Subassemblies + category tab.
4. Custom category clicks cannot leave dropdown open for repeat clicks.
5. `KSP.log`: no `NullReferenceException` in `RefreshSearchList` during apply; expect `ApplyPartCategory: navigated` / `ApplySubassembly: activated owning category`.

## v0.8.3.5 changes (tab navigation deep fix)

**Root cause (why v0.8.3.4 still failed):**

1. **Typing guard blocked refresh:** v0.8.1.3 blocks `EditorPartList.Refresh` while the search field is focused (`ShouldBlockPartsListRefresh`). Tab apply paths in v0.8.3.4 called `partList.Refresh()` without `StockSearchGuard.EnterSuppress()` and without blurring the field first — KSP.log showed `Blocked EditorPartList.Refresh(...) during Koobal typing guard` on every category/subassembly apply. Tabs never visually updated.
2. **SetState alone is insufficient:** `UIRadioButton.SetState(APPLICATION)` does not run the full stock handler chain. Stock uses `PartCategorizerButton.OnTrue`, `Category.OnTrueSUB(parent, subcategory)`, and `Category.OnTrueCATEGORY()` to switch tabs and rebuild filters.
3. **Custom subassembly categories under wrong tree:** cfg subassembly subcategories live under `PartCategorizer.subassemblies.subcategories`, not `subassembliesAll`. v0.8.3.4 only scanned/resolved `subassembliesAll` — `TryResolveEntry failed key='subasm:Test category'` in ModTest log.

**Fix (v0.8.3.5):**

- **`StockTabNavigator`:** unified tab apply — `EnterSuppress()`, blur search field, clear transient filters, then refresh. Lifts typing guard for suggestion clicks only.
- **`PartCategorizerUiHelper`:** activation order — parent tab → `OnTrueSUB` / `OnTrueCATEGORY` → `PartCategorizerButton.OnTrue` → `btnGeneric.onClick` → `SetState` fallback.
- **`CustomCategoryMatcher`:** scan/resolve custom subassembly subcategories under both `subassemblies` and `subassembliesAll`.
- **Logging:** `ApplyCategorizerTabNavigation: activated '...' refresh=PartSearch` / `ApplySubassemblyCategory: navigated to '...'` — no `Blocked EditorPartList.Refresh` during apply.

### v0.8.3.5 test steps (ModTest VAB)

1. Search `engine` → click **Engines** → Function/Propulsion tab + Engines subcategory active; engine parts visible.
2. Search `unknown` → click custom part category → Advanced mode + parent tab + subcategory.
3. Click custom subassembly category **Test category** → Subassemblies tab + that category tab (no `TryResolveEntry failed`).
4. Click specific subassembly → owning category tab + list filtered to one craft.
5. `KSP.log`: expect `StockTabNavigator` / `ApplyCategorizerTabNavigation` / `ApplyPartCategory` / `ApplySubassemblyCategory` success lines — **not** `Blocked EditorPartList.Refresh` during apply.

## v0.8.3.4 changes (category tab navigation fix — incomplete)

- **Stock category clicks navigate tabs:** `FilterFunction` (e.g. **Engines**) and `FilterCategory` suggestions activate the stock PartCategorizer tab chain via `ApplyCategorizerTabNavigation` — same UX as clicking the category button. No longer applies predicate `SearchFilterResult` overlays on the parts list. **Superseded by v0.8.3.5** — refresh was still blocked by typing guard; see v0.8.3.5 section.
- **Custom category resolve fix:** `CustomCategoryMatcher` reflection now includes public fields (`PartCategorizer.Category.button` is public). `TryResolveEntry` / `MergeStockScan` can read live category names again; fallback scans entire tree if stock index offsets miss a match.
- **Logging:** `[Koobal] ApplyCategorizerTabNavigation:` on success; warnings when tab-eligible kinds cannot resolve a live category (no silent predicate fallback).

### v0.8.3.4 test steps (ModTest VAB)

1. Search `engine` → click **Engines** → Function/Propulsion tab + Engines subcategory active; engine parts visible (not a text-filter overlay).
2. Search `unknown` → click a custom part category → Advanced mode + parent tab + subcategory.
3. Click custom subassembly category → Subassemblies tab + that category tab.
4. Click a specific subassembly → owning category tab + list filtered to one craft.
5. `KSP.log`: expect `ApplyCategorizerTabNavigation` or `ApplyPartCategory` / `ApplySubassemblyCategory` — not `ApplyCategorizerFilter` for tab-eligible rows.

## v0.8.3.3 changes (category icon eligibility)

- **Icons only on real category tabs:** dropdown icons restricted to navigable parts-UI tabs — stock `FilterFunction` / `FilterCategory` subcategory buttons and custom cfg categories. Tag, module, resource, tech, manufacturer, diameter, part, subassembly, and mod metadata rows are text-only again.
- **Centralized rule:** `PartSuggestion.ShouldShowCategoryIcon()` — e.g. query `engine` shows icon on **Engines** (function tab) only; tag/module matches like **Engine** stay text-only.

## v0.8.3.2 changes (programmatic wordmark branding)

- **Dropdown branding:** empty search field footer now renders a **Google Catull parody wordmark** via TextMeshPro rich-text color tags — K/o/o/b/a/l in classic Google colors. True transparency (alpha-0 footer Image; no RawImage PNG).
- **Font:** stock KSP TMP default (**LiberationSans SDF**) inherited from the dropdown header, bold + letter spacing to approximate serif Catull feel.
- **A/B experiment:** `PluginData/BrandingSettings.cfg` → `dropdownBranding = Wordmark` (default) or `FullTagline`. Restart VAB/SPH after editing.
- **Removed:** in-dropdown PNG `RawImage` loading (`BrandingTextureHelper`); PNG assets optional for marketing only.
- **Preserved:** history scroll above branding; branding only on empty query; stock Engines + custom category icons on real tab rows; apply behavior unchanged.

## v0.8.3.1 changes (image branding footer — superseded)

- **Dropdown branding:** empty search field footer showed a Koobal PNG logo via `RawImage`. **Superseded by v0.8.3.2** — PNG transparency did not render correctly in-game (white/checkerboard bleed).

## v0.8.3.0 changes (stock categorizer category icons)

- **Stock category icons:** all stock categorizer filter suggestions (`FilterFunction`, `FilterCategory`, `FilterManufacturer`, diameter/module/resource/tech/tag when a matching stock button exists) show the same right-rail icon layout as custom categories.
- **Icon resolution:** `StockCategorizerIconHelper` maps function filters to live `subcategoryFunction*` categories, walks the PartCategorizer category tree + `filters` list by display name, then reuses `CustomCategoryIconHelper` (`Icon.iconSelected` → button `RawImage`).
- **Custom categories preserved:** cfg-driven `CustomPartCategory` / `CustomSubassemblyCategory` icons unchanged; placeholder still shown when cfg icon missing.
- **Future:** mod-added categories via CCK/other mods may expose icons in mod metadata rather than cfg — separate integration track once stock path is stable.

## v0.8.2.3 changes (custom category icon clip fix)

- **Icon root cause:** icons loaded and cached correctly (`Custom category icon cache warmed: N icons`) but were **positioned outside each row** — right anchor + left pivot + positive X offset placed the 20px RawImage past the row's right edge, where the scroll **Viewport RectMask2D** clipped it entirely. v0.8.2.2's dark-vs-light diagnosis was secondary; even white textures were invisible.
- **Icon fix:** anchor right / pivot right / negative X inset so icons sit inside the reserved right rail; prefer `Icon.iconSelected` before live button RawImage (inactive tabs show dark unselected art); fallback `GetComponentInChildren<RawImage>` if `iconSprite` field cast fails; log warning when a row still has no texture.

## v0.8.2.2 changes (icon visibility + empty-query branding)

- **Icon root cause:** sprites were loading (`Custom category icon cache warmed: N icons`) but **invisible** — dropdown uses `iconNormal` (dark/unselected art) on dark row backgrounds. Stock toolbar shows dark icons on light chrome; our rows are the opposite.
- **Icon fix:** prefer `iconSelected` (light) for dropdown thumbnails; render via stock **`RawImage`** (texture + `uvRect`) copied from live `PartCategorizerButton.iconSprite` when available — matches stock category buttons.
- **Empty query:** removed fake browse suggestions (`CategorizerSuggestionIndex.GetBrowseSuggestions` fallback for empty field).
- **Branding footer:** empty search field shows pinned **KOOBAL SEARCH ENGINE** footer (bold, muted, centered). History scrolls above footer when present; branding-only panel when no history. Footer hidden once user types.

## v0.8.2.1 changes (custom category icon + apply fix)

- **Icon root cause:** stock RUI `Icon.iconNormal` is already `UnityEngine.Texture2D` — v0.8.2.0 looked for a nonexistent `.main` wrapper, so every sprite resolve returned null (`Custom category icon cache warmed: 0 sprites`).
- **Icon fix:** cast `iconNormal`/`iconSelected` directly to `Texture2D`; retry cache warm once `PartCategorizer.iconLoader` is ready (deferred coroutine + one-shot `EnsureCacheWarmed` before first category dropdown).
- **Apply root cause:** custom category apply added transient `EditorPartListFilter` predicates (parts-list filter) instead of navigating stock category tabs; `TryResolveEntry` failure also clobbered the indexed entry via `out entry`.
- **Apply fix:** custom part/subassembly category clicks navigate Advanced/Subassemblies tab chain only (parent tab → subcategory tab) — no transient parts-list filter. Subassembly craft suggestions unchanged (owning category tab + single-craft filter). Preserve indexed entry when live re-resolve fails.

## v0.8.2.0 changes (custom category icons)

- **Custom category thumbnails only:** `CustomPartCategory` and `CustomSubassemblyCategory` dropdown rows show a ~20px cfg icon **to the right** of text (optional transparent rail outside the search-field width) — not parts, subassemblies, or other suggestion kinds.
- **Text alignment preserved:** when category icons are shown, all rows keep the same centered text column width as the search field; icons sit in a right rail and may extend past the dropdown edge.
- **Per-category cfg icon:** `icon = ...` parsed from `PartCategories.cfg` SUBCATEGORY blocks (fallback parent icon) and `SubassemblyCategories.cfg`.
- **Stock icon pipeline:** icon name → `PartCategorizer.iconLoader.GetIcon()` → Sprite; cached by icon name + filter key at index bootstrap/merge only.
- **Colliding names:** part subcategories with duplicate display names show `parent › subcategory` (e.g. multiple `Unknown` rows).

## v0.8.1.5 changes (custom category cfg bootstrap)

- **Root cause:** stock reflection used wrong button property (`categoryName` vs stock `displayCategoryName`), so live scans and apply resolve always saw empty names.
- **Primary index:** one-time parse of install-level `GameData/Squad/PartList/PartCategories.cfg` + `SubassemblyCategories.cfg` on editor entry — O(files), no polling.
- **Stock merge:** instant `MergeStockScan()` supplements cfg entries with live `LiveCategory` + counts when PartCategorizer is ready; does not block dropdown.
- **Removed:** 15s / 0.5s custom category background poll and warning spam.
- **Preserved:** incremental create/delete hooks, apply path (tab + filter), index predicate === apply predicate via `TryResolveEntry`.

## v0.8.1.4 changes (SearchStop CTD fix — P0)

- **CTD fix:** `PartCategorizer.SearchStop` Harmony prefix no longer calls `InvokeBaseSearchStop` — virtual dispatch re-entered the patched override and caused `StackOverflowException` on VAB entry (~250ms after editor scene load).
- **Typing cancel:** `CancelPendingStockSearchForTyping` resets search flags directly (`CancelSearchRoutine` + `ResetTypingSearchFlags`) without invoking `SearchStop`.
- **Dropdown lag:** custom category 15s poll no longer blocks editor hook readiness — immediate `ScanStockCategories()` + background rescan coroutine.
- **Preserved:** keystroke stock leak fix, Enter-only search, subassembly/custom category apply, `EditorPartList.Refresh` block during typing guard.

## v0.8.1.3 changes (typing leak fix — P0)

- **Keystroke leak fixed:** `CancelPendingStockSearchForTyping` no longer invokes `PartCategorizer.SearchStop` (which set `refreshRequested` and made `UpdateDaemon` call `EditorPartList.Refresh` on every keystroke). Uses base `SearchStop` + clears `refreshRequested` instead.
- **Parts list frozen while typing:** Harmony blocks `PartCategorizer.SearchStop` refresh side-effects, `EditorPartList.Refresh` during typing guard, and `PartCategorizer.SearchRoutine` override during typing.
- **Enter with no match:** stock text-search fallback removed — parts list stays unchanged when Koobal finds nothing.
- **First focus:** retry show waits until editor index ready; if search field is already focused when hook completes, dropdown opens immediately.
- **Custom categories:** fixed ambiguous Harmony patches (`AddPart(AvailablePart)`, `Refresh(State)`); polls/rescans until categories indexed; logs category names found.

## v0.8.1.2 changes (typing guard — core value prop)

- **Stock search suppressed while typing:** Harmony guard blocks `SearchField_OnValueChange`, `SearchStart`, `SearchRoutine`, and `SearchFilter_` unless Koobal explicitly opts in via `EnterAllowStockTextSearch` (history-row `ApplySearch` only).
- **Parts list frozen during typing:** dropdown suggestions update on each keystroke; parts catalog does not reload/filter until the user clicks a suggestion row.
- **Orphan cleanup:** `CancelPendingStockSearchForTyping` stops pending `SearchRoutine` coroutines and resets stock search flags on focus and every value change.
- **Apply path:** suggestion apply still uses `SetTextWithoutNotify` where appropriate; `ApplySearch` wraps stock invoke in allow-window.
- **Enter key:** unchanged — commits search history and hides dropdown; does not apply stock text filter.

## v0.8.0.1 changes (rebrand — Koobal Search Engine)

- **Public name:** Koogle Search Engine → **Koobal Search Engine** — a Kerbalized play on Google search; "Koobal" is the kerbalized spelling (Kerbal + Google).
- **GameData folder:** `KoogleSearchEngine` → `KoobalSearchEngine`; DLL → `KoobalSearchEngine.dll`.
- **Log prefix:** `[Koobal]` (replaces `[Koogle]`).
- **Config migration:** `PluginData/History.cfg` and `DebugSettings.cfg` auto-copy from `GameData/KoogleSearchEngine/PluginData/` (or legacy `PartSearchSuggest/PluginData/`) on first load if the new path is missing.
- **Harmony IDs / filter keys:** `KoobalSearchEngine_*` (replaces `KoogleSearchEngine_*`).
- **Internal namespace:** C# remains `PartSearchSuggest` for minimal diff.
- **Version:** csproj `0.8.0.1`, user label **v0.8.0.1**, KSP `.version` → `0.8.0`.
- **Remove old install:** delete `GameData/KoogleSearchEngine/` after verifying migration (KSP must not load both DLLs).

## What it does

- Hooks `PartCategorizer.searchField` (stock search box)
- Shows a dropdown directly under the search bar while typing
- Suggests matching parts from `PartLoader.Instance.loadedParts` only (stock + mod parts loaded in-game)
- Text-only suggestion rows (centered part titles, with optional match-reason subtitle)
- Searches part name, title, tags, description, category, manufacturer, mod name/folder/author, module names, auto-generated function tags, and tech required
- Shows recent searches when the field is focused and empty
- Clicking a row fills the search box and runs the stock filter
- Dim overlay blocks clicks outside the dropdown; the parts catalog slides left while the dropdown is open (no ghosting, category bar stays visible)
- Close the dropdown with Escape, the header X button, clicking outside on the overlay, or by leaving the search field (End Edit)
- Clear recent searches with the trash button (left side of header) when viewing history

## Test it

1. Launch KSP and open the VAB or SPH.
2. Check `KSP.log` for:
   - `[Koobal] Editor scene detected — starting hook.`
   - `[Koobal] Indexed N loaded parts.`
   - `[Koobal] Hooked native editor search field.`
3. Click the stock parts search bar.
4. Type queries such as:
   - Part names/titles: `titan`, `mk2`
   - Categories: `engine`, `fuel tank`, `pod`
   - Tags/modules: `liquid`, `reaction wheel`
   - Manufacturer or tech: `rockomax`, `basicRocketry`
   - Mod name or author: partial author name (author row + that author's mods), mod display name, or stock author such as `squad`
5. Verify the dropdown:
   - Stays aligned under the search bar inside the parts panel
   - Is fully visible (no invisible overlay/canvas regression)
   - Has no ghosting of part icons behind rows (parts catalog slides left while dropdown is open)
   - Shows centered part titles in each row (subtitle shows why it matched, e.g. `category:engine`)
   - Scrolls when there are more rows than fit (~420px max panel height)
   - Does not let clicks pass through to parts beneath (overlay blocks the list)
6. Click a suggestion — dropdown closes, parts catalog returns, and the stock filter applies immediately (no Enter needed). For **part** rows, only that exact part should appear (`ApplyPrecisePart` in `KSP.log`). For **author/mod/suite** metadata rows, all matching parts should appear (`ApplyModAuthorFilter` / `ApplyModNameFilter` / `ApplyModSuiteFilter` in `KSP.log`). For history rows, stock text search still applies. Check `KSP.log` for `[Koobal] Row clicked:`, `ApplySuggestion (author|mod|suite|precise|stock):`, and filter log lines.
7. Re-open the dropdown, then dismiss it with Escape, the X button, or a click on the dim overlay — the parts catalog should slide back and be clickable again.
8. Clear the bar, click it again — recent searches should appear.

## Searchable fields

Suggestions match against part **title**, **internal name**, **tags**, **description**, **category** (e.g. `engine`, `fuel tank`), **manufacturer** (e.g. `rockomax`), **mod display name**, **mod folder name**, **mod/part author tokens** (comma-, semicolon-, ampersand-, and "and"-separated; parenthetical aliases), **module names/info**, **auto-generated function tags**, and **tech required**. Multi-word queries require each word to match at least one indexed field. The subtitle under each suggestion shows why it matched (e.g. `category:engine`, `mod:...`, `author:...`, `modfolder:...`).

## Build

```powershell
dotnet build "Source/PartSearchSuggest/PartSearchSuggest.csproj" -c Release
```

Output: `GameData/KoobalSearchEngine/Plugins/KoobalSearchEngine.dll`

## v0.8.0.3 changes (subassembly apply fix)

- **Subassembly click apply:** Switches to stock **Subassemblies** tab and filters the subassembly list to the indexed craft file path — same predicate as index (`SubassemblyMatcher.TryLoadEntry`). Does **not** call `EditorPartList.TapIcon` (which raced stock part text search and showed wrong parts like medkit/strut).
- **Search clear:** Clears active part search/custom filters before tab switch so leftover query text (`test`, `pineapple`) cannot repopulate the parts list.
- **Version:** csproj `0.8.0.3`, user label **v0.8.0.3**, KSP `.version` → `0.8.0`.

## v0.8.0.0 changes (subassembly search)

- **Subassembly suggestions:** Search saved subassemblies from `Saves/{save}/Subassemblies/` while in VAB/SPH. Rows show `subassembly · N parts`; click opens the stock subassembly tab filtered to that craft (v0.8.0.3+).
- **Editor entry scan:** Initial folder scan on VAB/SPH load; also scans optional `VAB/` and `SPH/` subfolders when present.
- **Incremental refresh:** Harmony hooks on `ShipConstruction.SaveSubassembly` and `EditorSubassemblyItem.DeleteSubassembly` update `SubassemblySuggestionIndex` only — never rebuilds part/metadata/categorizer indexes.
- **Same-session pickup:** Subassembly saved mid-session appears in suggestions without leaving the editor.
- **Version:** csproj `0.8.0.0`, user label **v0.8.0.0**, KSP `.version` → `0.8.0`.

## v0.7.9.1 changes (save-load indexing — no main menu work)

- **Save-load indexing:** `GameLoadBootstrap` (`KSPAddon.Startup.EveryScene`) builds all indexes during the loading screen after New Game / Load Game — KSC, flight, or tracking-station scene entry. Main menu only clears stale indexes (no database work).
- **VAB/SPH entry:** `EditorBootstrap` (`EditorAny`) attaches search UI only; consumes pre-built indexes (~instant hook). Editor fallback build if save-load indexing did not finish.
- **Log sequence (save load):** `[Koobal] Building search index during game load...` → `Search ready (basic)` → `Search ready (full)`.
- **Log sequence (VAB):** `[Koobal] Editor scene detected — attaching search UI (indexes pre-built at save load).` → `Hooked native editor search field.` within ~1 s.
- **Version:** csproj `0.7.9.1`, user label **v0.7.9.1**, KSP `.version` → `0.7.9`.

## v0.7.9.0 changes (deferred indexing — optimization milestone)

- **P0 — deferred secondary indexes:** `SuggestionIndex` builds first (~1–3 s on ~1700 parts); search field hooks immediately after. `MetadataSuggestionIndex` and `CategorizerSuggestionIndex` build in parallel background coroutines.
- **Search readiness logs:** `[Koobal] Search ready (basic)` when part-name queries work; `[Koobal] Search ready (full)` when author/mod/filter suggestions are indexed.
- **UI while indexing:** Search bar placeholder and dropdown header show `Loading suggestions…` until full index completes; part suggestions still appear during background build.
- **P2 — yield tuning:** Primary index batch size 75; secondary indexes 100 (less per-frame yield overhead while UI stays responsive).
- **Version:** csproj `0.7.9.0`, user label **v0.7.9.0**, KSP `.version` → `0.7.9`.

## v0.7.8.1l changes (VAB entry freeze fix — profile-02)

- **Editor part availability cache:** `EditorPartAvailability.WarmCache()` computes editor-available parts once per session; all index builders and matchers use the cached list (O(1) lookups instead of repeated `partTechAvailable` reflection per part).
- **Categorizer index build:** `TryAddVerifiedEntry` trusts first-pass discovered counts — no full-catalog rescan per filter; mismatch logging only when `dumpIndexStats = true`.
- **Frame-sliced index build:** `InitializeWhenReady` spreads `SuggestionIndex`, `MetadataSuggestionIndex`, and `CategorizerSuggestionIndex` builds across frames (`yield return null` every 50 parts); hook attaches after all indexes complete while UI stays responsive.
- **Mod metadata dedup:** `ModMetadataCache.Build()` runs once per editor session (idempotent).
- **Timing logs:** `[Koobal] SuggestionIndex complete in Nms`, `MetadataSuggestionIndex complete in Nms`, `CategorizerSuggestionIndex complete in Nms`.
- **Version:** csproj `0.7.8.13`, user label **v0.7.8.1l**, KSP `.version` remains `0.7.8`.

## v0.7.8.1k changes (suggestion row text layout fix)

- **Row text overlap fix:** subtitle rows now use separate title (white) and subtitle (blue) `TextMeshProUGUI` elements in a fixed-height `VerticalLayoutGroup` instead of one centered rich-text block — prevents title/subtitle clipping together and text bleeding outside row bounds on long metadata queries.
- **Clipping:** `RectMask2D` on each row; `enableAutoSizing = false`, `overflowMode = Ellipsis` on all suggestion labels.
- **Version:** csproj `0.7.8.12`, user label **v0.7.8.1k**, KSP `.version` remains `0.7.8`.

## v0.7.8.1j changes (rebrand — Koobal Search Engine)

- **Public name:** Part Search Suggest → **Koogle Search Engine** (Kerbalized play on Google search; superseded by Koobal in v0.8.0.1).
- **GameData folder:** `PartSearchSuggest` → `KoobalSearchEngine`; DLL → `KoobalSearchEngine.dll`.
- **Log prefix:** `[Koobal]` (replaces `[PartSearchSuggest]`).
- **Config migration:** `PluginData/History.cfg` and `DebugSettings.cfg` auto-copy from legacy `GameData/PartSearchSuggest/PluginData/` on first load if the new path is missing.
- **Internal namespace:** C# remains `PartSearchSuggest` for minimal diff; Harmony IDs and filter keys use `KoobalSearchEngine_*`.
- **Version:** csproj `0.7.8.11`, user label **v0.7.8.1j**, KSP `.version` remains `0.7.8`.
- **Remove old install:** delete `GameData/PartSearchSuggest/` after verifying migration (or leave — KSP will not load both if only the new folder has the DLL).

- **Removed broken hold system:** preemptive PointerDown hold, focus-based hold, session hold, instant alpha=0 mask, watchdog, `AssertCollapsedWhileHeld`, and `TransitionImmediate` Harmony patch.
- **Simple model restored:** `Show()` → `Collapse()` only when suggestions exist; `Hide()` → `RestoreIfDropdownClosed()`; zero matches → no collapse, parts list stays visible.
- **Slide-back guard (lightweight):** Harmony prefix blocks `Transition("In")` on `partsEditor` only while dropdown is open — no mask, no preempt, no focus coupling.
- **OnDestroy:** `ReleaseAllForEditorExit()` clears flags only — never calls `Restore()` during VAB exit.
- **Version:** csproj `0.7.8.10`, user label **v0.7.8.1i**, KSP `.version` remains `0.7.8`.

## v0.7.8.1h changes (fix 1g click regression — parts list stuck hidden)

- **Session hold vs preempt:** `_searchFieldFocused` no longer keeps hold after `EndPreemptiveHold()`. Session hold starts only on successful dropdown show or `onValueChanged` (typing). Empty click with no history calls `AbortShowAttempt()` → releases mask + restores parts panel.
- **Deferred collapse:** parts list `Collapse()` runs only when session or dropdown is active — not on bare focus or preempt-only snap.
- **Watchdog:** 45-frame safety net force-releases orphan hold if dropdown is closed and no session/preempt active.
- **Version:** csproj `0.7.8.9`, user label **v0.7.8.1h**, KSP `.version` remains `0.7.8`.

## v0.7.8.1g changes (fix 1f total failure — parts list invisible on VAB load)

- **Preempt hold decoupled from focus:** `BeginDropdownHold()` no longer sets `_searchFieldFocused = true`. A transient `_preemptiveHold` flag drives instant hide only until `ShowSuggestions` opens the dropdown or aborts; `EndPreemptiveHold()` releases when there are zero matches or the dropdown opens.
- **Post-hook grace period:** `SearchFieldPointerHandler` ignores `PointerDown` for two frames after hook attach — blocks spurious events that fired 7 ms after "Hooked native editor search field" and permanently hid the parts panel (alpha=0 + blocked `Transition("In")`).
- **Version:** csproj `0.7.8.8`, user label **v0.7.8.1g**, KSP `.version` remains `0.7.8`.

## v0.7.8.1f changes (fix 1e regressions — keep slide-back hold)

- **Multi-click dropdown recovery:** `SearchFieldPointerHandler` (`IPointerDownHandler`/`IPointerClickHandler`) replaces fragile `EventTrigger` wiring that could skip handlers when stock already registered PointerDown. PointerDown now triggers hold **and** idempotent `ShowSuggestions`; stale `onEndEdit`/`onDeselect` events are ignored while the field is still focused/selected.
- **Hide race fix:** `CancelPendingHide()` bumps `_hideRequestId` so delayed hide coroutines from prior blur cycles cannot close a freshly reopened dropdown.
- **VAB exit camera fix:** `ReleaseAllForEditorExit()` on editor destroy clears static hold/collapse flags and releases the hold mask **without** calling `Restore()` (which could fight stock exit transitions). `SuppressOpenTransition()` and transition guard now use `ReferenceEquals` via `IsPartsEditorTransition()` — never other `UIPanelTransition` instances. Removed Harmony postfixes that re-ran suppress logic after blocked transitions.
- **Version:** csproj `0.7.8.7`, user label **v0.7.8.1f**, KSP `.version` remains `0.7.8`.

## v0.7.8.1e changes (eliminate parts list pop-out flicker)

- **Extended hold scope:** parts panel stays collapsed while **dropdown is open OR search field is focused** (`onSelect`/`onDeselect`/`onEndEdit`). Hold is not released when the dropdown closes if the search bar still has focus.
- **PointerDown preempt:** `EventTrigger.PointerDown` on the search field calls `BeginDropdownHold()` before focus/`onSelect`, so instant hide + Harmony guard are active before stock `Transition("In")` can start on VAB entry click.
- **No premature restore:** `Hide()` only notifies dropdown closed; `SyncHoldState()` performs a single animated `Restore()` only when **both** dropdown is closed **and** search is blurred.
- **TransitionImmediate guard:** Harmony prefix/postfix on `TransitionImmediate(string, Action)` in addition to `Transition(string, Action)` — stock/editor code can open the panel without the animated path.
- **Abort in-flight open:** `SuppressOpenTransition()` clears `Transitioning` via reflection and snaps `TransitionImmediate("Out")` same frame if an open transition somehow starts.
- **Per-frame assert on hook:** `EditorSearchHook.Update` enforces hold even when the dropdown overlay is inactive (before first `Show()`).
- **Version:** csproj `0.7.8.6`, user label **v0.7.8.1e**, KSP `.version` remains `0.7.8`.

## v0.7.8.1d changes (parts list flicker fix)

- **Instant hold mask:** while the dropdown is open, `partsEditor.panelTransform` snaps to the Out position and `CanvasGroup.alpha=0` on the same frame — no waiting for `Transition("Out")` animation or `LateUpdate` re-assert.
- **Early hold activation:** `BeginDropdownHold()` runs at the start of search-field click/select and value-change (before `ShowSuggestions` / stock `Transition("In")`), so Harmony guard and instant hide are active on frame zero.
- **Broader transition guard:** blocks any non-`Out` `partsEditor.Transition(...)` while hold is active (not only `"In"`); blocked calls re-apply instant hide immediately.
- **Per-frame assert moved to `Update`:** `AssertCollapsedWhileHeld` runs in `Update` (not `LateUpdate`) so stock cannot win for a visible frame before correction.
- **Version:** csproj `0.7.8.5`, user label **v0.7.8.1d**, KSP `.version` remains `0.7.8`.

## v0.7.8.1c changes (Harmony patch fix — v0.7.8.1b hotfix)

- **Plugin load fix:** `PartsPanelTransitionGuard` Harmony patch now targets `UIPanelTransition.Transition(string)` explicitly — fixes `AmbiguousMatchException` during `EditorBootstrap.Awake()` that prevented the entire plugin from loading (v0.7.8.1b was zero-function with no user-visible error).
- **Isolated patch application:** `StockSearchGuard` and `PartsPanelTransitionGuard` each patch only their own nested types; failures in one guard are logged and do not block the other.
- **Rollback artifacts moved:** v0.7.0 rollback DLL/version/README live under `Source/PartSearchSuggest/rollback/` (not under `GameData/`) so KSP does not double-load a second assembly from the rollback folder.
- **Version:** csproj `0.7.8.4`, user label **v0.7.8.1c**, KSP `.version` remains `0.7.8`.

## v0.7.8.1b changes (clear history + slide-back guard)

- **Clear history button:** Trash icon now shows whenever recent-search mode is active **or** the query is empty and history entries exist (not only when `historyMode` flag is true). Visibility refreshes on every dropdown `Show()`.
- **Clear history tooltip:** Hovering the trash button shows stock KSP tooltip text **"Clear history"** via `TooltipController_Text`.
- **Parts panel slide-back:** While the dropdown is open, blocks stock `partsEditor.Transition("In")` (Harmony) and re-asserts collapse each frame if the panel slides back (fixes immediate VAB click race with editor load).
- **ModTest CCK policy:** `CommunityCategoryKit` is a permanent base layer on all ModTest profiles (junction from main) unless `skipBaseCck` is set in profile.json.
- **Version:** csproj `0.7.8.3`, user label **v0.7.8.1b**, KSP `.version` remains `0.7.8`.

## v0.7.8.1a changes (search history fix)

- **History on Enter:** Typed searches are saved to history when you press Enter (`onSubmit`), not only when the field loses focus (`onEndEdit`). Suggestion clicks still record history as before.
- **Clear history:** Trash button on the **left** of the "Recent searches" header (X stays on the right). One click clears `PluginData/History.cfg` and refreshes the dropdown.
- **Version:** csproj `0.7.8.2`, user label **v0.7.8.1a**, KSP `.version` remains `0.7.8`.

## v0.7.8.0a changes (mod testing phase baseline)

- **Index stats dump:** `PluginData/DebugSettings.cfg` → `dumpIndexStats = true` logs `[PartSearchSuggest] IndexStats:` lines on first editor index build (part counts, categorizer/mod index sizes, sample query hits).
- **Mod matrix testing framework:** `Source/PartSearchSuggest/testing/` — CKAN profiles, `apply-profile.ps1`, `parse-test-log.ps1`, `TEST_PROTOCOL.md`, `TEST_RUN_WORKFLOW.md`.
- **Version scheme:** mod-testing builds use **v0.7.8.0(x)** letter suffixes (csproj fourth segment `0.7.8.1`, `0.7.8.2`, …) until **v0.8.0.0** thumbnails track. See `ROLLBACK.md` for mapping.
- **Preserved:** v0.7.7 editor-only availability, v0.7.6 race fixes, scroll, filters, dedup unchanged.

## v0.7.7 changes

- **Editor-only part suggestions:** new `EditorPartAvailability.IsAvailableInEditor` mirrors stock `EditorPartList` inclusion — `ResearchAndDevelopment.partTechAvailable` (ExcludeFilters), `amountAvailable > 0` (AmountAvailableFilter), and `category != none` (same gate as `BasePartCategorizer.PartMatchesSearch`). Asteroids (`PotatoRoid`, `TechRequired = Unresearcheable`, `category = none`, `ModuleAsteroid`) and other non-VAB parts no longer appear in suggestions or filter counts.
- **Organic unification:** the same availability check is applied at index build, subtitle counts, dedup part-set hashing, `PartSuggestion.IsValid`, and all matcher predicates (`PartFilterMatcher`, `ModFilterMatcher`, `AuthorAttribution`). Broad-query guard denominator uses editor-available part count.
- **Preserved:** v0.7.6 race fixes, scroll, filters, dedup, zero-part guard, single-char guard unchanged.

## v0.7.6 changes

- **UI race fix (Enter + re-click):** orphan `HideDropdownAfterFrame` coroutines from `onEndEdit`/`onSubmit` could restore the parts panel while the dropdown was open again, or steal the first click after Enter. Hide requests now use a monotonic request id; pending hides are cancelled on focus, click, value change, or show. Explicit `EventTrigger.PointerClick` on the search field shows suggestions even when `onSelect` does not re-fire (field already focused after Enter).
- **Parts list pop-back guard:** `SearchDropdownPanel` tracks `_dropdownOpen`; `Hide()` restores the parts catalog only when transitioning open→closed. `PartsPanelCollapseHelper.RestoreIfDropdownClosed` adds a second guard against restore while dropdown is still open.
- **Hangar load race:** if focus/click arrives before indexes are built, `ShowSuggestions` retries next frame once categorizer hook is ready.
- **State logging:** focus, click, Enter/submit, end-edit, show/hide, collapse/restore transitions log to `KSP.log` for debugging intermittent reports.
- **Preserved:** v0.7.5 scroll (EventTrigger + Update fallback), filters, dedup, zero-part guard, single-char guard unchanged.

## v0.7.5 changes

- **Scroll fix (input):** v0.7.4 fixed layout clipping (`scrollable=true`) but KSP still did not scroll — root cause is the editor does not route mouse wheel to mod `ScrollRect` while the search `TMP_InputField` holds focus (stock uses explicit capture, not automatic `IScrollHandler`). Fix follows **`KSP.UI.Screens.CraftEntry` + `DirectoryController`**: `EventTriggerType.Scroll` on panel, header, viewport, and each row calls `ScrollRect.OnScroll()` and `PointerEventData.Use()`; **`Update()` fallback** forwards `Input.mouseScrollDelta` when the pointer is over the dropdown panel (same belt-and-suspenders approach needed in KSP editor UI). `scrollSensitivity` 40. Scroll is scoped to `_panelRect` only — not the dim overlay — so wheel over the dropdown should not zoom the VAB camera when `IsPointerOverGameObject` applies.
- **Header font:** "Recent searches" / "Suggestions" banner label 10→12pt; header bar height 13→16px to avoid clipping.
- **Single-char broad filter guard:** `SuggestionQueryGuards.MinSuggestionQueryLength = 2` — suppresses ModSuite/ModName/ModAuthor when query is one character; suppresses broad categorizer rows (tag, manufacturer, category, module, resource, tech) for single-char queries; also drops any suggestion whose `FilterKey` is one character or whose verified part count exceeds 90% of loaded parts. Typing `a` still shows part-name matches but not suite "A".
- **Preserved:** v0.7.4 ScrollAreaWrapper layout, zero-part exclusion, dedup, filters unchanged.

## v0.7.4 changes

- **ScrollRect fix (real):** root cause was `ScrollRect` implementing `ILayoutElement` on the same GameObject as the height-cap `LayoutElement` — Unity layout takes the max preferred height, so the panel expanded to fit all rows and the viewport never clipped overflow. Fix: height cap moved to a wrapper (`ScrollAreaWrapper`) with `LayoutElement` only; `ScrollRect` lives on an inner child that stretch-fills the wrapper. `ContentSizeFitter` restored on scroll content so row height drives content size. Debug log now reports actual panel/scrollArea/content/viewport heights and `scrollable=true` when content exceeds viewport.
- **Preserved:** v0.7.3 close-button containment (`RectMask2D`, 10×10 X), dynamic panel shrink for few results, filters/dedup unchanged.

## v0.7.3 changes

- **Close button containment:** header uses `RectMask2D` to clip children; layout group now controls child height; close button tightened to 10×10px with 1px vertical header padding; header background no longer steals raycasts. X visual and hit area stay inside the dropdown header — no bleed into the search bar.
- **ScrollRect fix (attempt):** scroll area height is set explicitly via `LayoutElement` (was incorrectly applied to the stretch-filled viewport where it had no effect). Removed `ContentSizeFitter` on scroll content (conflicted with manual content height and prevented scrolling). Scroll area background no longer blocks pointer events; `ScrollRect` stays enabled; layout rebuild + `Canvas.ForceUpdateCanvases()` before resetting scroll position. Dynamic panel shrink for few results preserved. **Did not fix scroll in-game** — superseded by v0.7.4 wrapper layout fix.

## v0.7.2 changes

- **Compact dropdown header (retry):** header bar height 16→12px, panel vertical padding 8→4px, header horizontal padding tightened, `childForceExpandHeight` disabled so layout groups stop stretching rows, TMP line spacing/margins zeroed on banner label and X. Close button hit area 16×14→11×11px (font 8pt). Font size kept at 9pt — dead space reduction, not crushed text.
- **Suggestion deduplication:** new `SuggestionDedupHelper` drops rows that filter to the same part set (or same FilterKey+Kind). Priority: part > mod name > author > suite > function > tag > module > category > other filters. Dedup runs in categorizer/metadata indexes and final merge in `EditorSearchHook`. Debug log: `Dedup 'query': dropped '...'`.
- **Organic index/apply unification:** every categorizer suggestion kind now shares one predicate via `PartFilterMatcher.PartMatchesFilter` / `CountMatchingFilter` — index subtitle counts, click apply, and dedup all use the same logic. `ModFilterMatcher` and `AuthorAttribution` follow the same pattern for mod/author rows.
- **Tag-based intake (replaces v0.7.1a):** removed divergent `filterIntake` / `PartIsAirIntake` (`ModuleResourceIntake`) custom predicate. Query `intake` surfaces **Intakes** from the literal `intake` part tag (`FilterTag`); click filters `part.tags` / `partInfo.tags` token match. Index count verified against apply predicate before the row is shown.
- **On-demand suggestions:** categorizer rows (tags, categories, manufacturers, modules, resources, tech, diameters, stock functions) are built from loaded parts at runtime — no hardcoded filter terms except stock function button registry keys mapped to live `PartCategorizer` predicates.
- **Preserved:** author/mod/engine stock function filters, StockSearchGuard race protection.

## v0.7.1a changes (intake fix attempt A — superseded by v0.7.2 tag filter)

User-facing label **v0.7.1a**; assembly/csproj `0.7.1.1`; KSP `.version` file stays `0.7.1` (no suffix support). See `Source/PartSearchSuggest/ROLLBACK.md` for version mapping.

- **Intakes filter fix:** query `intake` now surfaces a dedicated **Intakes** function row (`FilterKey=filterIntake`) with a custom `ModuleResourceIntake` predicate — not the broad Aerodynamics (`filterAero`) bucket. Fixes blank parts list after clicking **Intakes**.
- **Suggestion registry:** `SuggestionFilterRegistry.cs` documents every function filter's stock field or custom predicate; index and apply share the same resolver.
- **Search race guard:** block stock `SearchStart` / `SearchRoutine` while a custom filter is active so display labels like `Intakes` cannot be overwritten by failed stock text search.
- **Module filter parity:** module suggestions prefer `moduleDisplayName` as `FilterKey` (matches stock module filter buttons).
- **Debug logging:** `Row clicked` and `ApplyCategorizerFilter` log `kind`, `FilterKey`, match count, and apply path; query `intake` logs all emitted categorizer rows.

## v0.6.9 changes

- **Stock categorizer filter suggestions:** typing terms that match the VAB/SPH parts categorizer buttons now surfaces first-class dropdown rows for function (engines, control/RCS, fuel tanks, etc.), manufacturer, diameter/bulkhead profile, part category, common modules, resources, and tech tier — each with a subtitle showing kind and part count (e.g. `function · 42 parts`, `diameter · 118 parts`).
- **Filter on click:** categorizer rows apply via `SearchFilterResult` custom predicates (`ApplyCategorizerFilter`) using stock `PartCategorizer` function filter criteria where available, with the same `StockSearchGuard` suppress/refresh path as author/mod filters (clears search field first, restores display label, blocks stock `SearchFilter_` overwrite).
- **Deduped ranking:** categorizer suggestions rank alongside author/mod rows; redundant individual part rows suppressed when a matching categorizer filter is shown.
- **Compact dropdown header:** reduced header bar height, label font size, and horizontal padding so "Recent searches" / "Suggestions" takes less vertical space.
- **Smaller close button:** X button and icon scaled down to match the slimmer header while staying clickable.

## v0.6.8 changes

- **Unified author attribution:** suggestions, part counts, and `ApplyModAuthorFilter` now share `AuthorAttribution.PartMatchesAuthorFilter`. A part matches when any of its `part.author` tokens, mod `.version`/CKAN metadata authors, or indexed mod `AuthorTokens` hit the filter key.
- **Author alias canonicalization:** `AuthorCanonicalizer` groups spelling variants (`LisiasT`, `Lisias`, `Lisias T`) via shared searchable forms. Suggestion `FilterKey`, subtitle part counts, and filter predicates all use the canonical group.
- **CKAN author merge:** CKAN co-authors are merged into existing `.version` author strings instead of only filling empty fields.
- **Filter debug log:** `ApplyModAuthorFilter: author='X' matched N parts` — N matches the subtitle count and visible parts list.

## v0.6.5 changes

- **CKAN author enrichment:** when a mod `.version` file omits `author`/`AUTHOR` (e.g. Aviation Lights), installed-mod authors from `CKAN/registry.json` are merged into the metadata cache. Parts in that mod are attributed to CKAN-listed co-authors such as `LisiasT`, so partial queries like `lisi` / `lisias` surface the author row with accurate part counts.
- **Author display names:** camelCase author tokens (e.g. `LisiasT`) display as spaced words (`Lisias T`) while `FilterKey` keeps the canonical token for filtering.
- **Author match debug log:** queries of 3+ characters log matched author tokens, part counts, and ranks to `KSP.log` (e.g. `Author match 'lisi': LisiasT (8 parts, rank 0)`).

## v0.6.4 changes

- **Strict author matching:** author/mod-author suggestions use prefix and word-boundary matching only — no mid-token substring hits (e.g. `lisi` no longer matches inside `NovaSilisko`). CamelCase and spaced names (`Lisias T`, `LisiasT`) split into searchable word forms.
- **Author filter fix:** metadata author/mod/suite clicks clear the stock search field before applying `SearchFilterResult`, then restore the display label with `SetTextWithoutNotify`. Stock `PartMatchesSearch` only checks titles/tags, so leaving an author name in the box returned zero parts despite a correct custom filter.
- **JSON author arrays:** `.version` files with `"AUTHOR": ["A", "B"]` are parsed into co-author tokens.
- **Slash-separated authors:** `Tim / Composer` style strings split on `/` as well as `,`, `;`, `&`, and `and`.
- **Ranking:** full-token author prefix > word-prefix author > mod name exact/prefix > suite > mod via author > mod name contains > individual parts.

## v0.6.3 changes

- **Co-author tokenization:** `.version` author strings and per-part `author` fields are split on `,`, `;`, `&`, the word `and`, and parentheses/brackets. Each token is indexed separately for suggestions, part search, and author filtering.
- **Author → mod linkage:** partial author matches show the author row first, then installed mod rows for every mod where any co-author token matches (subtitle `mod · N parts`). Co-authored mods appear under each listed author.
- **Author filter includes co-authors:** clicking an author row filters to all parts from mods where that author is any co-author token, not only exact full-string matches.
- **Dynamic mod catalog:** metadata index seeds from all installed `.version` files at load, then merges part counts and authors from loaded parts.
- **Ranking:** author prefix > mod name exact/prefix > author contains > mod suite > mod via author contains > mod name contains > individual parts.

## v0.6.2 changes

- **First-class author/mod suggestions:** partial author names show as their own dropdown row (subtitle `author · N parts`), not only individual parts with author in the subtitle. Mod names work the same: a multi-mod family query shows a **suite** row; a specific mod display name shows a **mod** row.
- **Metadata filter on click:** clicking author/mod/suite rows filters the parts list to all matching parts via stock `SearchFilterResult` (`ApplyModAuthorFilter`, `ApplyModNameFilter`, `ApplyModSuiteFilter`). Part rows still use exact single-part filter (`ApplyPrecisePart`); history still uses stock text search.
- **Deduped ranking:** metadata suggestions rank above redundant part rows; parts matched only via the same author/mod metadata are suppressed when a metadata row is shown.
- **Visual distinction:** metadata rows use a slightly different background tint; subtitles show `author ·`, `mod ·`, or `suite ·` with part/mod counts.

## v0.6.1 changes

- **Mod name and author search:** each part is indexed with its GameData mod folder, mod display name (from `.version` `name`/`NAME` when available), and author tokens (from `.version` when available, plus per-part `author` from the part cfg). Search a mod display name to surface parts from that mod; search an author token to match via part/mod author fields.
- **Mod metadata cache:** `.version` files are read once per mod folder at index time; unversioned mods fall back to folder name (stock parts resolve to `Squad`).
- **MatchReason subtitles:** mod matches show `mod:...`, `modfolder:...`, or `author:...`.

## v0.6.0 changes

- **Metadata-first matching:** suggestion ranking prefers tag, category, module, manufacturer, auto-tag, and tech over title/name, with description weakest. Multi-word queries score every word (AND logic); module names indexed with camelCase splitting; resource/module summaries, bulkhead profiles, and type descriptions indexed too.
- **MatchReason subtitles:** each row shows why it matched (e.g. `category:engine`, `module:module engines`, `auto:propulsion`).
- **Larger scrollable dropdown:** panel grows up to 420px tall; overflow rows scroll inside a `ScrollRect` viewport. Up to 24 suggestions shown.
- **Precise part filter on click:** selecting a part suggestion calls stock `SearchFilterResult` with an exact `part.name` predicate (`ApplyPrecisePart`) so the parts list shows that part only. Manual typing and history selections still use stock text search (`ApplySearch`).
- Required log lines: `ApplySuggestion (precise):` + `ApplyPrecisePart: exact filter for '...'` on part click; `ApplySuggestion (stock):` for history.

## v0.5.3 changes

- **Stock parts catalog slide (primary):** collapse now calls `EditorPanels.Instance.partsEditor.Transition("Out")` — the same UIPanelTransition that slides the entire `Panel Parts List` off-screen when stock UI toggles it. Restore calls `Transition("In")`.
- **Direct position fallback:** if the stock transition does not move the panel, sets `partsEditor.panelTransform.anchoredPosition` to the Out state position `(-350, 0)` from transition config.
- **Hide fallback restored:** if both slide paths fail, `CanvasGroup.alpha=0` on `Panel Parts List` (or scroll rect as last resort). Log reports `method=HideFallback visible=false`. Collapse is never a no-op.
- **v0.5.2 regression fixed:** v0.5.2 slid `partsEditorModes` / Construction Tools (120px sub-panel) first; worldDelta verification passed but the parts catalog stayed visible. Wrong target blocked the hide fallback entirely.
- One-time discovery log dumps all `EditorPanels` UIPanelTransition fields via reflection plus `partsEditor` / `partsEditorModes` / `partcategorizerModes` state positions.
- Collapse runs at the start of `Show()` (before dropdown positioning).
- Required log line: `PartsPanelCollapse: Collapse method=PartsEditorTransition` or `method=HideFallback`.

## v0.5.2 changes

- **Real parts-catalog slide (fixes v0.5.1 vanish-without-move):** v0.5.1 slid only `partListScrollRect` (209px scroll viewport). Offset slide moved icon content off-screen inside a fixed parent frame, so parts vanished but the catalog column position never changed.
- Collapse now tries slide targets in order: `partsEditorModes.panelTransform`, catalog-column ancestor (walk up from scroll rect until width ~250–450px, typically `PartList Area`), `EditorPartList` root, then `partsEditor.panelTransform`. Each candidate is verified by world-space X movement before acceptance.
- Layout groups on parents are temporarily disabled and `LayoutElement.ignoreLayout` is set during slide so anchoredPosition/offset changes are not reset every frame.
- **Hide fallback (last resort):** if no candidate produces visible world-space movement, `CanvasGroup.alpha=0` hides the catalog column only (category/subcategory columns untouched). Log reports `method=HideFallback visible=false`.
- Required log line: `PartsPanelCollapse: Collapse method=SlidePanel target=... before=(...) after=(...) visible=true`
- **Click suggestion → search + close + restore:** removed `ActivateInputField()` after apply (it re-fired `onSelect` → `ShowSuggestions` → immediate re-collapse). Search field is cleared before stock `SearchField_OnValueChange` to prevent duplicate query text.
- Dismiss paths (Escape, X, overlay, End Edit) still call `Hide()` → `Restore()`.

## v0.5.1 changes

- **Fixed parts catalog collapse (v0.5.0 regression):** `partsEditorModes` `Out` state only shifts Y (330,-60)→(330,36) — cargo-tab vertical layout, not a horizontal hide. That path reported success but moved nothing visible; RectTransform slide never ran.
- Collapse now slides `EditorPartList.partListScrollRect` left (part icon grid only — category/subcategory columns stay put). Uses offset slide for stretch anchors, anchoredPosition otherwise.
- CanvasGroup on the scroll rect blocks raycasts while collapsed (alpha unchanged so the slide stays visible-off-screen, not a fade hack).
- One-time discovery log dumps `partsEditorModes`, `partcategorizerModes` (Simple/Advanced — category arrows), and `partsEditor` state positions plus EditorPanels hierarchy.
- Required log line: `PartsPanelCollapse: Collapse: method=RectTransformSlide, target=..., beforePos=..., afterPos=..., success=true`
- Restore on Hide/dismiss/suggestion unchanged; dropdown architecture unchanged.

## v0.5.0 changes

- **Proper parts catalog collapse (broken in-game):** removed v0.4.7 `scrollListSub` hide (that removed the category/subcategory bar, not the part icons)
- Attempted `EditorPanels.partsEditorModes` `Out` transition — wrong target; only adjusts vertical position for cargo layout
- Preserved: v0.4.4/4.7 overlay architecture, PointerDown clicks, StockSearchHelper, match-reason subtitles

## v0.4.7 changes

- **Visibility restored:** reverted to v0.4.4 overlay architecture — single overlay under `FindOverlayParent` (search-field parent hierarchy), **no nested Canvas** on overlay root or panel
- **Ghosting fixed without canvas tricks:** `PartCategorizer.scrollListSub` is hidden while the dropdown is open and restored on dismiss — part icons cannot bleed through because they are not rendered
- Removed v0.4.5/v0.4.6 regressions: editor-root Canvas parent, overlay Canvas with `overrideSorting`, and `ListBlocker` z-order hacks
- Show() log includes `scrollListHidden`, screen coords, overlay parent name
- Preserved: row PointerDown clicks, StockSearchHelper auto-filter, match-reason subtitles, whiteTexture sprites

## v0.4.6 changes

- Fixed invisible dropdown (regression from v0.4.5): overlay is now a **direct child of the editor root Canvas** with a **single overlay Canvas** (not nested on the panel only, not buried via `FindOverlayParent`)
- Overlay Canvas copies editor settings (`renderMode`, `worldCamera`, `sortingLayerID`) plus `overrideSorting`, `sortingOrder = editor + 100`, and `planeDistance + 1` for ScreenSpaceCamera — entire overlay (dim + list blocker + dropdown) renders above all parts UI
- Panel positioned via screen-space conversion into the full-screen overlay rect; `SetAsLastSibling` on show
- Show() log includes overlay renderMode, sortingOrder, planeDistance, panel screen position
- Preserved: row PointerDown clicks, StockSearchHelper, match-reason subtitles, ListBlocker for ghosting, whiteTexture sprites
- **Did not work in-game:** KSP.log showed active overlay and valid world corners, but dropdown was still invisible — nested Canvas on overlay root repeats the v0.4/v0.4.5 regression pattern in KSP editor UI

## v0.4.5 changes

- Fixed part-icon ghosting: root cause was **draw order** — `scrollListSub` part icons render as later siblings in the same canvas, painting over dropdown rows despite opaque Images. Fix combines (1) overlay sibling index after parts list, (2) `Canvas.overrideSorting` (order 300) on dropdown panel only with inherited render mode/camera, and (3) opaque `ListBlocker` rect over the parts list viewport
- Show() debug log now includes overlay vs scrollList sibling indices, panel sorting order, and list-blocker state
- Clicking a suggestion now triggers stock search immediately via `SearchField_OnValueChange` + `SearchStart` (no Enter / debounce wait)
- Match-reason subtitle is larger/brighter (`size=10`, `#9EC8E8`) so category/tag/manufacturer matches are easier to see
- README documents searchable fields

## v0.4.4 changes

- Fixed positioning bug: panel top now anchors to search field **bottom** edge (v0.4.3 incorrectly used top-right Y, causing overlap)
- Fixed ghosting: all UI Image components now use a white sprite (`Texture2D.whiteTexture`) — Images without a sprite render invisible in Unity UI
- Dim blocker is raycast-only (alpha 0) so no semi-transparent layer bleeds part icons through the dropdown
- Fixed dead row clicks: `EventTrigger.PointerDown` fires before `onEndEdit` hides the dropdown; `Button.onClick` alone was too late
- Added click logging: `[PartSearchSuggest] Row clicked: {text}` and `ApplySuggestion: '{query}'`
- Hide-after-end-edit delayed by 2 frames as safety net

## v0.4.3 changes

- Restored v0.3 single-overlay architecture: dim blocker and dropdown panel are siblings under one overlay root (fixes row clicks intercepted by dim on a separate canvas layer)
- Restored v0.3 positioning: world-corner conversion with panel top anchored to search field bottom (`topY`, not `bottomY`)
- Solid opaque panel stack (backing + panel + row images, all alpha 1.0) renders above dim overlay to stop part-icon ghosting
- Match-reason subtitle on suggestion rows (e.g. `tag:titan`, `manufacturer:rockomax`) confirms expanded search index is active

## v0.4.2 changes

- Fixed dropdown not appearing: removed nested overlay Canvas (overrideSorting broke rendering in KSP editor UI); dropdown is parented under the search field parent like v0.3, with opaque panel/blocker + SetAsLastSibling for ghosting instead of a separate canvas
- Added richer Show() debug logging (parent names, world corners, zero-count guard)

## v0.4.1 changes

- Attempted fix: overlay canvas inherits editor render mode/world camera (dropdown still did not render — superseded by v0.4.2)

## v0.4 changes

- Fixed visual ghosting: overlay canvas uses override sorting; solid opaque blocker sits under the dropdown; panel uses double opaque backing
- Expanded search index across part metadata (title, name, tags, description, category, manufacturer, modules, auto-tags, tech required)
- Multi-word queries require each word to match at least one indexed field
- Removed unused thumbnail helper code

## Known POC limits

- No keyboard navigation (↑↓ Enter)
- Basic Unity UI styling (no KSP skin matching)
- No Harmony patches (direct event hook only)
- Compatibility with other search mods not tested yet
